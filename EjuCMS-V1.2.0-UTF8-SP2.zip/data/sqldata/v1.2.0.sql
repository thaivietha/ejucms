ALTER TABLE `eju_archives` ADD COLUMN `users_id`  int(11) UNSIGNED NOT NULL DEFAULT 0 COMMENT '用户id' AFTER `area_id`;
ALTER TABLE `eju_archives` ADD COLUMN `show_time`  int(11) UNSIGNED NOT NULL DEFAULT 0 COMMENT '置顶时间' AFTER `users_id`;
ALTER TABLE `eju_xinfang_content` MODIFY COLUMN `greening_rate`  varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '绿化率' AFTER `plot_ratio`;
ALTER TABLE `eju_xinfang_content` MODIFY COLUMN `property`  varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '房屋产权' AFTER `greening_rate`;
ALTER TABLE `eju_xinfang_content` MODIFY COLUMN `households`  varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '户数' AFTER `property`;
ALTER TABLE `eju_xinfang_content` MODIFY COLUMN `carport`  varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '车位数' AFTER `households`;
ALTER TABLE `eju_xinfang_content` MODIFY COLUMN `property_fee`  varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '物业费' AFTER `manage_company`;

DROP TABLE IF EXISTS `eju_users`;
CREATE TABLE `eju_users` (
`id`  int(11) UNSIGNED NOT NULL AUTO_INCREMENT ,
`level_id`  tinyint(3) UNSIGNED NOT NULL DEFAULT 1 COMMENT '会员级别' ,
`username`  varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '用户名' ,
`nickname`  varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '昵称' ,
`true_name`  varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '真实姓名' ,
`is_mobile`  tinyint(1) NULL DEFAULT 0 COMMENT '绑定手机号，0为不绑定，1为绑定' ,
`mobile`  varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '手机号码' ,
`is_email`  tinyint(1) NULL DEFAULT 0 COMMENT '绑定邮箱，0为不绑定，1为绑定' ,
`email`  varchar(60) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT 'email' ,
`qq`  varchar(13) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT 'qq号码' ,
`password`  varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '密码' ,
`litpic`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '头像' ,
`status`  tinyint(1) NULL DEFAULT 1 COMMENT '状态(0=屏蔽，1=正常)' ,
`add_time`  int(11) NULL DEFAULT 0 COMMENT '添加时间' ,
`update_time`  int(11) NULL DEFAULT 0 COMMENT '更新时间' ,
`is_del`  tinyint(1) UNSIGNED NOT NULL DEFAULT 0 ,
`reg_time`  int(11) UNSIGNED NULL DEFAULT 0 COMMENT '注册时间' ,
`register_place`  tinyint(1) NULL DEFAULT 2 COMMENT '注册位置。后台注册不受注册验证影响，1为后台注册，2为前台注册。默认为2。' ,
`open_id`  varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '微信唯一标识openid' ,
`admin_id`  int(10) NULL DEFAULT 0 COMMENT '关联管理员ID' ,
`is_activation`  tinyint(1) NULL DEFAULT 1 COMMENT '是否激活，0否，1是。\r\n后台注册默认为1激活。\r\n前台注册时，当会员功能设置选择后台审核，需后台激活才可以登陆。' ,
`is_lock`  tinyint(1) NULL DEFAULT 0 COMMENT '是否被锁定冻结' ,
PRIMARY KEY (`id`)
)ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COMMENT='会员表';


DROP TABLE IF EXISTS `eju_users_config`;
CREATE TABLE `eju_users_config` (
`id`  int(11) NOT NULL AUTO_INCREMENT COMMENT '会员功能配置表ID' ,
`name`  varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '配置的key键名' ,
`value`  text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '配置的value值' ,
`desc`  varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '键名说明' ,
`inc_type`  varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '配置分组' ,
`update_time`  int(11) NULL DEFAULT 0 COMMENT '更新时间' ,
PRIMARY KEY (`id`)
)ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COMMENT='会员配置表';


INSERT INTO `eju_users_config` VALUES ('1', 'users_reg_notallow', 'www,bbs,ftp,mail,user,users,admin,administrator,eyoucms', '不允许注册的会员名', 'users', '1547890773');
INSERT INTO `eju_users_config` VALUES ('2', 'users_verification', '0', '验证方式', 'users', '1573545028');
INSERT INTO `eju_users_config` VALUES ('3', 'users_open_register', '0', '开放注册', 'users', '1573456943');

DROP TABLE IF EXISTS `eju_users_content`;
CREATE TABLE `eju_users_content` (
`id`  int(11) UNSIGNED NOT NULL AUTO_INCREMENT ,
`users_id`  int(11) UNSIGNED NOT NULL DEFAULT 0 ,
`status`  tinyint(1) NULL DEFAULT 1 COMMENT '状态(0=屏蔽，1=正常)' ,
`is_del`  tinyint(1) UNSIGNED NOT NULL DEFAULT 0 ,
`last_login`  int(11) NULL DEFAULT 0 COMMENT '最后登录时间' ,
`last_ip`  varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '最后登录ip' ,
`login_count`  int(11) NULL DEFAULT 0 COMMENT '登录次数' ,
`all_send`  int(11) UNSIGNED NOT NULL DEFAULT 0 COMMENT '共发布条数' ,
`ershou_send`  int(11) UNSIGNED NOT NULL DEFAULT 0 COMMENT '共发布二手房数' ,
`zufang_send`  int(11) UNSIGNED NOT NULL DEFAULT 0 COMMENT '共发布租房数' ,
`all_top`  int(11) UNSIGNED NOT NULL DEFAULT 0 COMMENT '全部置顶数' ,
`ershou_top`  int(11) UNSIGNED NOT NULL DEFAULT 0 COMMENT '全部二手房置顶数' ,
`zufang_top`  int(11) UNSIGNED NOT NULL DEFAULT 0 COMMENT '全部租房置顶数' ,
`day_send`  int(11) UNSIGNED NOT NULL DEFAULT 0 COMMENT '当天共发布条数' ,
`day_ershou_send`  int(11) UNSIGNED NOT NULL DEFAULT 0 COMMENT '当天总共发布二手房数' ,
`day_zufang_send`  int(11) UNSIGNED NOT NULL DEFAULT 0 COMMENT '当天总共发布租房数量' ,
`day_top`  int(11) UNSIGNED NOT NULL DEFAULT 0 COMMENT '当天总共置顶条数' ,
`day_ershou_top`  int(11) UNSIGNED NOT NULL DEFAULT 0 COMMENT '当天总共置顶二手房条数' ,
`day_zufang_top`  int(11) UNSIGNED NOT NULL DEFAULT 0 COMMENT '当天总共置顶租房条数' ,
`add_time`  int(11) NULL DEFAULT 0 COMMENT '添加时间' ,
`update_time`  int(11) NULL DEFAULT 0 COMMENT '更新时间' ,
PRIMARY KEY (`id`)
)ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COMMENT='会员信息表';


DROP TABLE IF EXISTS `eju_users_level`;
CREATE TABLE `eju_users_level` (
`id`  int(11) UNSIGNED NOT NULL AUTO_INCREMENT ,
`level_name`  varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '名称' ,
`free_day_send`  int(6) UNSIGNED NOT NULL DEFAULT 0 COMMENT '每天免费发布' ,
`free_all_send`  int(6) UNSIGNED NOT NULL DEFAULT 0 COMMENT '共免费发布' ,
`fee_day_top`  int(6) UNSIGNED NOT NULL DEFAULT 0 COMMENT '每天免费置顶' ,
`fee_all_top`  int(6) UNSIGNED NOT NULL DEFAULT 0 COMMENT '共免费置顶' ,
`check_ershou`  tinyint(1) UNSIGNED NOT NULL DEFAULT 1 COMMENT '二手房是否需要审核' ,
`check_zufang`  tinyint(1) UNSIGNED NOT NULL DEFAULT 1 COMMENT '租房是否需要审核' ,
`status`  tinyint(1) UNSIGNED NOT NULL DEFAULT 1 COMMENT '状态（1：启用，0：关闭）' ,
`add_time`  int(11) NULL DEFAULT 0 COMMENT '添加时间' ,
`update_time`  int(11) NULL DEFAULT 0 COMMENT '更新时间' ,
`is_del`  tinyint(1) UNSIGNED NOT NULL DEFAULT 0 ,
`is_system`  tinyint(1) UNSIGNED NOT NULL DEFAULT 0 COMMENT '注册默认级别' ,
PRIMARY KEY (`id`)
)ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COMMENT='会员级别表';

INSERT INTO `eju_users_level` VALUES ('1', '注册会员', '5', '50', '5', '50', '1', '1', '1', '1572511812', '1573438344', '0', '1');
INSERT INTO `eju_users_level` VALUES ('2', '中级会员', '5', '0', '5', '0', '0', '1', '1', '1572512423', '1573035421', '0', '0');
INSERT INTO `eju_users_level` VALUES ('3', '高级会员', '0', '0', '0', '0', '0', '0', '1', '1573442442', '1573442442', '0', '0');

DROP TABLE IF EXISTS `eju_users_log`;
CREATE TABLE `eju_users_log` (
`id`  int(11) UNSIGNED NOT NULL AUTO_INCREMENT ,
`users_id`  int(11) NOT NULL DEFAULT 0 COMMENT '用户id' ,
`aid`  int(11) UNSIGNED NOT NULL DEFAULT 0 COMMENT '文档id' ,
`type`  tinyint(3) UNSIGNED NOT NULL DEFAULT 1 COMMENT '类型（1：二手发布，2：二手置顶，3：租房发布，4：租房置顶）' ,
`is_del`  tinyint(1) UNSIGNED NOT NULL DEFAULT 0 ,
`add_time`  int(11) NULL DEFAULT 0 COMMENT '添加时间' ,
`update_time`  int(11) NULL DEFAULT 0 COMMENT '更新时间' ,
`num`  int(6) UNSIGNED NOT NULL DEFAULT 1 COMMENT '变动条数' ,
PRIMARY KEY (`id`)
)ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COMMENT='会员日志表';


update eju_archives set show_time = add_time where show_time = 0;

INSERT INTO `eju_smtp_tpl` (`tpl_name`, `tpl_title`, `tpl_content`, `send_scene`, `is_open`, `add_time`, `update_time`) VALUES ('会员注册', '验证码已发送至您的邮箱，请登录邮箱查看验证码！', '${content}', '2', '1', '1544763495', '1544763495');
INSERT INTO `eju_smtp_tpl` (`tpl_name`, `tpl_title`, `tpl_content`, `send_scene`, `is_open`, `add_time`, `update_time`) VALUES ('绑定邮箱', '验证码已发送至您的邮箱，请登录邮箱查看验证码！', '${content}', '3', '1', '1544763495', '1544763495');
INSERT INTO `eju_smtp_tpl` (`tpl_name`, `tpl_title`, `tpl_content`, `send_scene`, `is_open`, `add_time`, `update_time`) VALUES ('找回密码', '验证码已发送至您的邮箱，请登录邮箱查看验证码！', '${content}', '4', '1', '1544763495', '1544763495');

