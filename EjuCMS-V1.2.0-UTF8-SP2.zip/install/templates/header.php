<div class="header">
<img src="images/install_logo.png">
</div>