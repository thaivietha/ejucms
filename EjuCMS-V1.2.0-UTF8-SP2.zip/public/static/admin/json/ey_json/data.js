{
  "code": 0,
  "msg": "ok",
  "data": [
    {
      "id": 1,
      "name": "xx",
      "sex": "male",
      "pid": -1
    },
    {
      "id": 2,
      "name": "xx",
      "sex": "male",
      "pid": 1
    },
    {
      "id": 3,
      "name": "xx",
      "sex": "male",
      "pid": 1
    },
    {
      "id": 4,
      "name": "xx",
      "sex": "male",
      "pid": 1
    },
    {
      "id": 5,
      "name": "xx",
      "sex": "male",
      "pid": -1
    },
    {
      "id": 6,
      "name": "xx",
      "sex": "male",
      "pid": 5
    },
    {
      "id": 7,
      "name": "xx",
      "sex": "male",
      "pid": 5
    },
    {
      "id": 8,
      "name": "xx",
      "sex": "male",
      "pid": 6
    },
    {
      "id": 9,
      "name": "xx",
      "sex": "male",
      "pid": 6
    },
    {
      "id": 10,
      "name": "xx",
      "sex": "male",
      "pid": 9
    },
    {
      "id": 11,
      "name": "xx",
      "sex": "male",
      "pid": 9
    }
  ],
  "count": 11
}