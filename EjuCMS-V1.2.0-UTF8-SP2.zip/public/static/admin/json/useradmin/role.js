{
  "code": 0
  ,"msg": ""
  ,"count": "100"
  ,"data": [{
    "id": "1"
    ,"rolename": "超级管理员"
    ,"limits": "管理所有的管理员"
    ,"descr": "拥有至高无上的权利"
    ,"check": true
  },{
    "id": "2"
    ,"rolename": "管理员"
    ,"limits": "所有列表的管理"
    ,"descr": "事情很多，权力很大"
    ,"check": true
  },{
    "id": "3"
    ,"rolename": "文章撰写员"
    ,"limits": "负责文章的编写"
    ,"descr": "文采第一的人才集合"
    ,"check": false
  },{
    "id": "4"
    ,"rolename": "纠错员"
    ,"limits": "负责文章内容的修改"
    ,"descr": "暂无"
    ,"check": false
  },{
    "id": "5"
    ,"rolename": "统计人员"
    ,"limits": "对数据进行统计"
    ,"descr": "暂无"
    ,"check": false
  },{
    "id": "6"
    ,"rolename": "评估员"
    ,"limits": "对统计数据进行评估"
    ,"descr": "及时捕捉市场发展动态"
    ,"check": false
  },{
    "id": "7"
    ,"rolename": "采购员"
    ,"limits": "负责员工的伙食"
    ,"descr": "暂无"
    ,"check": false
  },{
    "id": "8"
    ,"rolename": "推销员"
    ,"limits": "介绍销售公司产品"
    ,"descr": "暂无"
    ,"check": false
  }]
}