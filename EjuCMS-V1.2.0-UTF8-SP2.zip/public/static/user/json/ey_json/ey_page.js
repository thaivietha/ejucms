{
  "code": 0
  ,"msg": ""
  ,"count": "11"
  ,"data": [{
     "id": "1"
      ,"title": "公司简介"
      ,"typeid": "关于我们"
      ,"is_special": "1"
	  ,"click": "1"
	  ,"update_time": "2019-08-20"
	  ,"sort_order":"100"
    }, {
     "id": "2"
      ,"title": "公司荣誉"
      ,"typeid": "关于我们"
      ,"is_special": "0"
	  ,"click": "1"
	  ,"update_time": "2019-08-20"
	  ,"sort_order":"100"
    }, {
     "id": "3"
      ,"title": "预约面试"
      ,"typeid": "关于我们"
      ,"is_special": "1"
	  ,"click": "1"
	  ,"update_time": "2019-08-20"
	  ,"sort_order":"100"
    }, {
     "id": "4"
      ,"title": "人才招聘"
      ,"typeid": "关于我们"
      ,"is_special": "1"
	  ,"click": "1"
	  ,"update_time": "2019-08-20"
	  ,"sort_order":"100"
    }, {
     "id": "5"
      ,"title": "联系我们"
      ,"typeid": "关于我们"
      ,"is_special": "1"
	  ,"click": "1"
	  ,"update_time": "2019-08-20"
	  ,"sort_order":"100"
   
  }]
}