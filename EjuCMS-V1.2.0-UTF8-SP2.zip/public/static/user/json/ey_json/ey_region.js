{
  "code": 0
  ,"msg": ""
  ,"count": "11"
  ,"data": [{
     "id": "1"
      ,"name": "海南省"
      ,"parent_id": "无"
      ,"status": "1"
      ,"is_hot": "1"
	  ,"sort_order":"110"
    }, {
     "id": "2"
      ,"name": "甘肃省"
      ,"parent_id": "无"
      ,"status": "1"
      ,"is_hot": "1"
	  ,"sort_order":"110"
    }, {
     "id": "3"
      ,"name": "广西省"
      ,"parent_id": "无"
      ,"status": "0"
      ,"is_hot": "1"
	  ,"sort_order":"110"
    }, {
     "id": "4"
     ,"name": "广东省"
      ,"parent_id": "无"
      ,"status": "1"
      ,"is_hot": "0"
	  ,"sort_order":"110"
    }, {
     "id": "5"
      ,"name": "海口市"
      ,"parent_id": "海南省"
      ,"status": "1"
      ,"is_hot": "1"
	  ,"sort_order":"110"
    }, {
     "id": "6"
       ,"name": "北京市"
      ,"parent_id": "河北省"
      ,"status": "1"
      ,"is_hot": "1"
	  ,"sort_order":"110"
    }, {
     "id": "7"
      ,"name": "江苏省"
      ,"parent_id": "无"
      ,"status": "0"
      ,"is_hot": "1"
	  ,"sort_order":"110"
    }, {
     "id": "8"
      ,"name": "高雄市"
      ,"parent_id": "台湾省"
      ,"status": "1"
      ,"is_hot": "1"
	  ,"sort_order":"110"
	}, {
     "id": "9"
      ,"name": "吉林省"
      ,"parent_id": "无"
      ,"status": "1"
      ,"is_hot": "0"
	  ,"sort_order":"110"
	}, {
     "id": "10"
      ,"name": "新疆"
      ,"parent_id": "无"
      ,"status": "1"
      ,"is_hot": "1"
	  ,"sort_order":"110"
	}, {
     "id": "11"
      ,"name": "陕西省"
      ,"parent_id": "无"
      ,"status": "1"
      ,"is_hot": "1"
	  ,"sort_order":"110"
		
  }]
}