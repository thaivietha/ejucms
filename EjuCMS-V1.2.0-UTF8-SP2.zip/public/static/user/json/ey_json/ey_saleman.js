{
  "code": 0
  ,"msg": ""
  ,"count": "11"
  ,"data": [{
     "id": "1"
      ,"saleman_name": "经纪人001"
      ,"saleman_mobile": "13677777777"
      ,"saleman_qq": "123456789"
	  ,"status": "1"
	  ,"saleman_email":"123456789@qq.com"
    }, {
     "id": "2"
      ,"saleman_name": "经纪人002"
      ,"saleman_mobile": "13677777777"
      ,"saleman_qq": "123456789"
	  ,"status": "0"
	  ,"saleman_email":"123456789@qq.com"
    }, {
     "id": "3"
       ,"saleman_name": "经纪人003"
      ,"saleman_mobile": "13677777777"
      ,"saleman_qq": "123456789"
	  ,"status": "1"
	  ,"saleman_email":"123456789@qq.com"
    }, {
     "id": "4"
     ,"saleman_name": "经纪人004"
      ,"saleman_mobile": "13677777777"
      ,"saleman_qq": "123456789"
	  ,"status": "1"
	  ,"saleman_email":"123456789@qq.com"
    }, {
     "id": "5"
     ,"saleman_name": "经纪人005"
      ,"saleman_mobile": "13677777777"
      ,"saleman_qq": "123456789"
	  ,"status": "1"
	  ,"saleman_email":"123456789@qq.com"
    }, {
     "id": "6"
    ,"saleman_name": "经纪人006"
      ,"saleman_mobile": "13677777777"
      ,"saleman_qq": "123456789"
	  ,"status": "0"
	  ,"saleman_email":"123456789@qq.com"
    }, {
     "id": "7"
     ,"saleman_name": "经纪人007"
      ,"saleman_mobile": "13677777777"
      ,"saleman_qq": "123456789"
	  ,"status": "1"
	  ,"saleman_email":"123456789@qq.com"
    }, {
     "id": "8"
   ,"saleman_name": "经纪人008"
      ,"saleman_mobile": "13677777777"
      ,"saleman_qq": "123456789"
	  ,"status": "1"
	  ,"saleman_email":"123456789@qq.com"
	}, {
     "id": "9"
    ,"saleman_name": "经纪人009"
      ,"saleman_mobile": "13677777777"
      ,"saleman_qq": "123456789"
	  ,"status": "0"
	  ,"saleman_email":"123456789@qq.com"
	}, {
     "id": "10"
     ,"saleman_name": "经纪人010"
      ,"saleman_mobile": "13677777777"
      ,"saleman_qq": "123456789"
	  ,"status": "1"
	  ,"saleman_email":"123456789@qq.com"
	}, {
     "id": "11"
    ,"saleman_name": "经纪人011"
      ,"saleman_mobile": "13677777777"
      ,"saleman_qq": "123456789"
	  ,"status": "1"
	  ,"saleman_email":"123456789@qq.com"
		
  }]
}