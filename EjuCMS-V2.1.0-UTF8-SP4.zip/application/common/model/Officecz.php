<?php
/**
 * User: xyz
 * Date: 2019/10/15
 * Time: 10:38
 */

namespace app\common\model;

use think\Model;

class Officecz extends Model
{
    //初始化
    protected function initialize()
    {
        // 需要调用`Model`的`initialize`方法
        parent::initialize();
    }
}