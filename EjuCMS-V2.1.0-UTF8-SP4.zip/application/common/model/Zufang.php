<?php
/**
 * User: xyz
 * Date: 2019/10/21
 * Time: 11:03
 */

namespace app\common\model;

use think\Model;

class Zufang extends Model
{
    //初始化
    protected function initialize()
    {
        // 需要调用`Model`的`initialize`方法
        parent::initialize();
    }
}